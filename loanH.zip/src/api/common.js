import { baseUrl } from './config'

export function checkAuth() {
  
}