export default {
  baseUrl: ''
}