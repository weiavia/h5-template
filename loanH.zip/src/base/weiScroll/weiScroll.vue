<template>
  <div class="wsc" @touchstart.prevent="tStart"  @touchend.prevent="tEnd" @touchmove.prevent>
    <div id="wscWrapper" class="wsc_wrapper">
      <slot />
    </div>
  </div>
</template>

<script>
export default {
  props: {
    type: {
      type: String,
      default: '2'
    }
  },
  data () {
    return {
      zIndex: 1
    };
  },
  mounted() {
    this.wrapper = document.getElementById('wscWrapper')
    this.sections = this.wrapper.children
    this.curIndex = 0
    this.dir = 0
    this.flag = true

    if(this.type === '1') {
      this.initType1()
    } else {
      this.initType2()
    }

  },
  methods: {
    initType1() {
      let documentHeight = document.body.clientHeight

      // 设置section高度为文档高度
      for(let i = 0; i<this.sections.length; i++) {
        this.sections[i].style.height = documentHeight + 'px'
      }
      // 设置section容器高度为所有section高度总和
      this.wrapper.style.height = documentHeight * this.sections.length + 'px'
    },
    initType2() {
      let documentHeight = document.body.clientHeight

      for(let i = 0; i<this.sections.length; i++) {
        this.sections[i].addEventListener('transitionend', () => {
          this.transitionend()
        })
      }

      this.wrapper.classList.add('type2')
      setTimeout(() => {
        this.wrapper.classList.add('transition')
      },0)
      this.sections[0].classList.add('active')
    },
    tStart(e) {
      let touch = event.targetTouches[0]
      this.touchPos = {
        x: touch.clientX,
        y: touch.clientY
      }
    },
    tEnd(e) {
      let touch = e.changedTouches[0]
      let start = this.touchPos.y
      let end = touch.clientY

      var absv = Math.abs(start - end)
      if(absv > 30) {
        if(start - end > 0) {
          if(this.type === '2') {
            this.scrollDown2()
          } else {
            this.scrollDown()
          }
        } else {
          if(this.type === '2') {
            this.scrollUp2()
          } else {
            this.scrollUp()
          }
        }
      }
    },
    transitionend() {
      this.flag = !this.flag
      if(!this.flag)
        return
      this.resetStyle()
    },
    scrollUp2() {
      if(this.curIndex == 0)
        return
      this.dir = 0
      let index = --this.curIndex 
      this.setStyle(index)
    },
    
    scrollDown2() {
      if(this.curIndex == this.sections.length - 1)
        return
      this.dir = 1
      // this.wrapper.classList.remove('transition')
      let index = ++this.curIndex 
      // 预备
      this.setStyle(index)
    },

    // 重置样式
    resetStyle(index) {
      index = 0
      if(this.dir === 1) {
         index = this.curIndex - 1
         this.sections[index].style.transform = 'translateY(-100%)'
      } else {
        index = this.curIndex + 1
        console.log('index:', index)
        this.sections[index].style.transform = 'translateY(100%)'
      }
     
      this.sections[index].style.opacity = '0'
    },

    // 设置样式
    setStyle(index) {
      console.log(index)
      this.sections[index].width = ''
      this.sections[index].style.opacity = '1'
      this.sections[index].style.zIndex = ++ this.zIndex
      this.sections[index].style.transform = 'translateY(0)'
    },

    scrollUp() {
      
      if(this.curIndex == 0)
        return
      let nextPos = --this.curIndex * this.documentHeight
      this.wrapper.style.transform = 'translateY('+ -nextPos +'px)'
    },
    scrollDown() {
      
      if(this.curIndex == this.items.length - 1)
        return
      let nextPos = ++this.curIndex * this.documentHeight
      this.wrapper.style.transform = 'translateY('+ -nextPos +'px)'
    }
  }
}
</script>

<style lang="scss" scoped>
  .wsc {
    position: absolute;
    width: 100%;
    height: 100%;
    background:lightgoldenrodyellow;
    overflow: hidden;
  }

  .wsc_wrapper {
    transition: all 1s;
  }

  .wsc_wrapper.type2 {
    .section {
      width: 100%;
      height: 100%;
      top: 0;
      left: 0;
      position: absolute;
      transform: translateY(100%);
      opacity: 0;
      overflow: hidden;
    }

    .section.active {
      transform: translateY(0);
      opacity: 1;
    }

  }

  .wsc_wrapper.transition {
    .section {
      transition: all 1s;
    }
  }
  
</style>